package com.yz.service;

import java.util.List;
import com.yz.bean.FMAData;

public interface FMADataService {
	
	List<FMAData> selectAll();
	
	FMAData selectByChipID(String chipid);

}
