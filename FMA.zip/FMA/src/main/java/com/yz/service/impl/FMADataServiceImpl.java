package com.yz.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yz.bean.FMAData;
import com.yz.dao.FMADataMapper;
import com.yz.service.FMADataService;

@Service
public class FMADataServiceImpl implements FMADataService{
	
	@Autowired
	private FMADataMapper fmadataMapper;

	@Override
	public List<FMAData> selectAll() {
		// TODO Auto-generated method stub
		return fmadataMapper.selectAll();
	}

	@Override
	public FMAData selectByChipID(String chipid) {
		// TODO Auto-generated method stub
		return fmadataMapper.selectByPrimaryKey(chipid);
	}

}
