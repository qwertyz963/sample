package com.yz.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yz.bean.FMAData;
import com.yz.service.FMADataService;

@Controller
public class FMADataController {
	
	@Autowired
	private FMADataService fmadataService;
	
	@RequestMapping("/main")
	public String getFMADataAll(@RequestParam Map<String, String> params, Model model, HttpSession session){
		String chipid = (String) params.get("chipid").replace(" ", "");
		
		FMAData fd  = fmadataService.selectByChipID(chipid);
		
		model.addAttribute("chipid", fd.getTftChipId());
		model.addAttribute("defectcode", fd.getDefectCode());
		model.addAttribute("chipx", fd.getChipX());
		model.addAttribute("chipy", fd.getChipY());
		model.addAttribute("sheetx", fd.getSheetX());
		model.addAttribute("sheety", fd.getSheetY());
		model.addAttribute("poxx", fd.getPoxX());
		model.addAttribute("poxy", fd.getPoxY());
		model.addAttribute("defectsize", fd.getDefectSize());
		model.addAttribute("currentdefcode", fd.getCurrentDefCode());
		model.addAttribute("currentdefcodedesc", fd.getCurrentDefCodeDesc());
		model.addAttribute("photoaddress", fd.getPhotoAddress());
		model.addAttribute("gap", fd.getGap());
		model.addAttribute("lmtime", fd.getLmTime());
		return "dataAll";
		
	}

}
